from django.shortcuts import render
from django.http import JsonResponse
from . import multi

# Create your views here.

def demo(request):
    return render(request, 'demo/demoPage.html')

def answer(request):
    ans = multi.inv(request.GET.get('matrix'))
    ans = str(ans)
    return JsonResponse({'matrix': ans})