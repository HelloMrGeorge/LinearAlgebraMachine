"""
Package for web.
"""
